---
name: midnight-compact-guide
description: Comprehensive guide to writing Compact smart contracts for Midnight Network. Use this skill when writing, reviewing, debugging, or learning Compact code. Triggers on "write a contract", "Compact syntax", "Midnight smart contract", "ledger state", "circuit function", or "ZK proof".
license: MIT
metadata:
  author: webisoft
  version: "1.0.0"
  midnight-version: "0.27.0"
---

# Midnight Compact Language Guide

Complete reference for writing privacy-preserving smart contracts in Compact, Midnight's domain-specific language for zero-knowledge applications.

## When to Use

Reference this guide when:
- Writing new Compact smart contracts
- Debugging Compact compilation errors
- Understanding Compact syntax and types
- Implementing privacy patterns (selective disclosure, commit-reveal)
- Reviewing Compact code for best practices

## Quick Reference

### Basic Contract Structure

```compact
pragma language_version >= 0.19;

import CompactStandardLibrary;

// Public state (visible on blockchain)
export ledger myCounter: Counter;
export ledger myValue: Uint<64>;

// Circuit function (modifies state, generates ZK proof)
export circuit increment(): [] {
  myCounter.increment(1);
}

// Pure function (no state change, no proof)
export pure function add(a: Uint<64>, b: Uint<64>): Uint<64> {
  return a + b;
}
```

## Rule Categories

| Priority | Category | Description | Prefix |
|----------|----------|-------------|--------|
| 1 | Syntax | Basic language syntax and structure | `syntax-` |
| 2 | Types | Data types and type system | `types-` |
| 3 | State | Ledger and private state management | `state-` |
| 4 | Circuits | Circuit functions and ZK proofs | `circuit-` |
| 5 | Privacy | Privacy patterns and selective disclosure | `privacy-` |
| 6 | Patterns | Common design patterns | `patterns-` |

## Syntax Rules

### syntax-pragma
Every Compact file must start with a pragma declaration:
```compact
pragma language_version >= 0.19;
```

### syntax-imports
Import the standard library for built-in types:
```compact
import CompactStandardLibrary;
```

### syntax-exports
Use `export` keyword to make items accessible:
```compact
export ledger myState: Counter;      // Public state
export circuit myFunction(): [] {}    // Public circuit
```

### syntax-assertions
Use `assert` for validation with error messages:
```compact
assert(condition, "Error message");
assert(amount > 0, "Amount must be positive");
```

## Type Rules

### types-counter
`Counter` - Incrementable integer type:
```compact
export ledger score: Counter;

export circuit addPoints(points: Uint<64>): [] {
  score.increment(points);
}
```

### types-uint
`Uint<N>` - Unsigned integer with N bits:
```compact
export ledger balance: Uint<64>;     // 64-bit unsigned int
export ledger flags: Uint<8>;        // 8-bit unsigned int
```

### types-boolean
`Boolean` - True/False values:
```compact
export ledger isActive: Boolean;

export circuit activate(): [] {
  isActive = true;
}
```

### types-bytes
`Bytes<N>` - Fixed-size byte arrays:
```compact
export ledger hash: Bytes<32>;       // 32-byte hash
export ledger address: Bytes<32>;    // Address as bytes
```

### types-vector
`Vector<T, N>` - Fixed-size arrays:
```compact
export ledger cards: Vector<Uint<8>, 52>;  // Deck of 52 cards
export ledger players: Vector<Bytes<32>, 4>; // 4 player addresses
```

### types-map
`Map<K, V>` - Key-value mapping:
```compact
export ledger balances: Map<Bytes<32>, Uint<64>>;
export ledger scores: Map<Bytes<32>, Counter>;
```

## State Rules

### state-ledger-public
Ledger state is PUBLIC - visible to everyone:
```compact
// GOOD: Public data in ledger
export ledger totalSupply: Counter;
export ledger winner: Bytes<32>;

// BAD: Sensitive data in ledger (visible to all!)
// export ledger playerHand: Vector<Uint<8>, 5>; // Don't do this!
```

### state-private-witnesses
Private state is defined in TypeScript witnesses:
```typescript
// witnesses.ts
export type GamePrivateState = {
  playerHand: number[];    // Private - only owner sees
  secretMove: number;      // Private - hidden until reveal
};

export const createPrivateState = (): GamePrivateState => ({
  playerHand: [],
  secretMove: 0,
});

export const witnesses = {};
```

### state-map-access
Access map values with bracket notation:
```compact
export ledger balances: Map<Bytes<32>, Uint<64>>;

export circuit transfer(from: Bytes<32>, to: Bytes<32>, amount: Uint<64>): [] {
  assert(balances[from] >= amount, "Insufficient balance");
  balances[from] = balances[from] - amount;
  balances[to] = balances[to] + amount;
}
```

## Circuit Rules

### circuit-basic
Circuits modify state and generate ZK proofs:
```compact
export circuit increment(): [] {
  counter.increment(1);
}
```

### circuit-parameters
Circuits can take parameters:
```compact
export circuit deposit(amount: Uint<64>): [] {
  assert(amount > 0, "Amount must be positive");
  balance.increment(amount);
}
```

### circuit-private-witness
Private data passed as witness (not stored on chain):
```compact
// The actualBalance is a PRIVATE witness input
export circuit proveBalanceAbove(
  accountId: Bytes<32>,
  threshold: Uint<64>,
  actualBalance: Uint<64>  // Private - comes from witness
): [] {
  assert(actualBalance >= threshold, "Balance below threshold");
  // Only the PROOF that balance >= threshold is public
  // The actual balance value is NEVER revealed
}
```

### circuit-return-empty
Circuits return `[]` (empty tuple):
```compact
export circuit myCircuit(): [] {
  // state changes here
}
```

## Privacy Rules

### privacy-commit-reveal
Use commit-reveal for hidden moves:
```compact
// Phase 1: Commit (hash of move + salt)
export ledger commitment: Bytes<32>;

export circuit commitMove(hash: Bytes<32>): [] {
  commitment = hash;
}

// Phase 2: Reveal (verify hash matches)
export circuit revealMove(
  move: Uint<8>,
  salt: Bytes<32>,
  expectedHash: Bytes<32>
): [] {
  // Verify the commitment matches
  // Then process the move
}
```

### privacy-selective-disclosure
Prove claims without revealing data:
```compact
// Prove balance exceeds threshold WITHOUT revealing exact balance
export circuit proveBalanceThreshold(
  threshold: Uint<64>,
  actualBalance: Uint<64>  // Private witness
): [] {
  assert(actualBalance >= threshold, "Insufficient balance");
  // Verifier learns: balance >= threshold
  // Verifier does NOT learn: actual balance value
}
```

### privacy-nullifiers
Prevent double-actions with nullifiers:
```compact
export ledger usedNullifiers: Map<Bytes<32>, Boolean>;

export circuit vote(
  nullifier: Bytes<32>,
  choice: Uint<8>
): [] {
  assert(!usedNullifiers[nullifier], "Already voted");
  usedNullifiers[nullifier] = true;
  // Process vote
}
```

## Common Patterns

### patterns-game-state
Manage game states with Uint<8>:
```compact
// 0 = Waiting, 1 = Playing, 2 = Finished
export ledger gameState: Uint<8>;

export circuit startGame(): [] {
  assert(gameState == 0, "Game already started");
  gameState = 1;
}

export circuit endGame(): [] {
  assert(gameState == 1, "Game not in progress");
  gameState = 2;
}
```

### patterns-multi-player
Track multiple players:
```compact
export ledger players: Map<Bytes<32>, Boolean>;
export ledger playerCount: Counter;
export ledger maxPlayers: Uint<8>;

export circuit joinGame(playerId: Bytes<32>): [] {
  assert(!players[playerId], "Already joined");
  assert(playerCount < maxPlayers, "Game full");
  players[playerId] = true;
  playerCount.increment(1);
}
```

### patterns-admin-only
Restrict functions to admin:
```compact
export ledger admin: Bytes<32>;

export circuit adminAction(
  callerId: Bytes<32>,
  action: Uint<8>
): [] {
  assert(callerId == admin, "Not authorized");
  // Perform admin action
}
```

## Compilation

### Compile Contract
```bash
# Navigate to contract directory
cd counter-contract

# Compile with Compact
compactc src/counter.compact --output src/managed

# Or use npm script
npm run build
```

### Common Compilation Errors

| Error | Solution |
|-------|----------|
| `Unknown type` | Import CompactStandardLibrary |
| `Type mismatch` | Check Uint bit sizes match |
| `Undeclared variable` | Declare with `export ledger` or as parameter |
| `Invalid pragma` | Use `pragma language_version >= 0.19;` |

## Best Practices

1. **Keep circuits simple** - Complex circuits = longer proof generation
2. **Use Counter for incrementing** - Don't use raw Uint for counters
3. **Assert early** - Validate inputs at start of circuit
4. **Private by default** - Only put truly public data in ledger
5. **Meaningful errors** - Include descriptive assert messages

## Full Examples

See `/rules/` directory for complete rule files with detailed examples:
- `rules/syntax-pragma.md`
- `rules/types-counter.md`
- `rules/circuit-private-witness.md`
- `rules/privacy-selective-disclosure.md`

## References

- [Midnight Docs](https://docs.midnight.network)
- [Compact Language Guide](https://docs.midnight.network/compact)
- [Starter Template](https://github.com/MeshJS/midnight-starter-template)
